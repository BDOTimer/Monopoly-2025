#ifndef PLAYER_H
#define PLAYER_H
///----------------------------------------------------------------------------|
/// "player.h"
///----------------------------------------------------------------------------:
#include "common.h"

struct  Player   : Object
{       Player(const Data& dat) : Object(dat)
        {
        }

private:

};

#endif // PLAYER_H
